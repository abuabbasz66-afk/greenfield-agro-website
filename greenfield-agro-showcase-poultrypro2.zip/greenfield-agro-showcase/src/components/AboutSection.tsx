import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Leaf, Target, Users, TrendingUp, ArrowRight } from "lucide-react";
import ceoPhoto from "@/assets/ceo-photo.jpg";
import partner from "@/assets/partner.jpeg";

const AboutSection = () => {
  const achievements = [
    { number: "5+", label: "Years of Excellence" },
    { number: "100+", label: "Satisfied Customers" },
    { number: "10+", label: "Farm Partners" },
    { number: "100%", label: "Organic Quality" },
  ];

  const values = [
    {
      icon: Leaf,
      title: "Sustainability",
      description:
        "Committed to environmentally responsible farming practices that preserve our land for future generations.",
    },
    {
      icon: Target,
      title: "Quality First",
      description:
        "Every product meets our rigorous quality standards, ensuring you receive only the best agricultural products.",
    },
    {
      icon: Users,
      title: "Community Focus",
      description:
        "Supporting local farmers and communities while building lasting relationships with our customers.",
    },
    {
      icon: TrendingUp,
      title: "Innovation",
      description:
        "Embracing modern farming techniques and technology to improve efficiency and product quality.",
    },
  ];

  return (
    <section id="about" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16 space-y-4">
          <Badge variant="outline" className="mb-4 border-primary text-primary">
            About GreenField
          </Badge>
          <h2 className="text-4xl lg:text-5xl font-serif font-bold text-primary">
            Rooted in Growth, Driven by Excellence
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
            For 5 years, Greenfield Contracts & Agro Limited has been at the
            forefront of Katsina's Agricultural revolution, providing Premium
            products and sustainable farming solutions
          </p>
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-20">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="space-y-6">
              <h3 className="text-3xl font-serif font-bold text-primary">
                Our Story & Mission
              </h3>
              <div className="space-y-4 text-lg text-muted-foreground leading-relaxed">
                <p>
                  GreenField Contracts & Agro Limited was founded with a strong
                  desire to make a difference in Nigeria’s agricultural sector
                  by tackling one of the nation’s most pressing challenges—food
                  security. What began as a modest initiative has evolved into a
                  growing enterprise dedicated to creating lasting solutions for
                  sustainable food production and supply. Our story is one of
                  growth, resilience, and purpose. We are driven by the vision
                  of building a future where every household has access to safe,
                  nutritious, and affordable food, while empowering farmers and
                  strengthening communities across Nigeria.
                </p>
                <p>
                  Our mission is simple yet powerful: to provide the highest
                  quality agricultural products while supporting sustainable
                  farming practices that benefit both our customers and the
                  environment.
                </p>
                <p>
                  Based in Katsina State, we have built strong relationships
                  with local farmers and communities, creating a network of
                  excellence that ensures consistent quality and reliable
                  supply.
                </p>
              </div>
            </div>

            {/* Achievements */}
            <div className="grid grid-cols-2 gap-6">
              {achievements.map((achievement, index) => (
                <div
                  key={index}
                  className="text-center p-4 bg-accent/10 rounded-lg"
                >
                  <div className="text-3xl font-bold text-primary mb-2">
                    {achievement.number}
                  </div>
                  <div className="text-sm font-medium text-muted-foreground">
                    {achievement.label}
                  </div>
                </div>
              ))}
            </div>

            <Button className="bg-gradient-primary text-primary-foreground hover:shadow-agro-md transition-agro">
              Learn More About Us
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>

          {/* Right Content - CEO Section */}
          <div className="space-y-8">
            <div className="bg-card rounded-2xl p-8 shadow-agro-lg">
              <div className="flex items-start gap-6 mb-6">
                <img
                  src={ceoPhoto}
                  alt="CEO - GreenField Agro"
                  className="w-36 h-36 rounded-full object-cover shadow-agro"
                />
                <div>
                  <h4 className="text-xl font-bold text-primary mb-1">
                    Dr. Abubakar Sadiq Abbas
                  </h4>
                  <span className="block text-xs font-semibold text-primary/80 mb-2">
                    CEO / FOUNDER
                  </span>
                  <p className="text-muted-foreground mb-4 text-sm">
                    Dr. Abubakar Sadiq Abbas is an agribusiness and technology
                    leader with 10+ years of experience in poultry production
                    and farm management. He led digital transformation
                    initiatives that streamlined operations, cut costs, and
                    improved overall farm productivity.
                  </p>
                  <p className="text-muted-foreground mb-4 text-sm">
                    With a strong background in ICT and business strategy, Dr.
                    Abbas integrates innovation into agriculture, using
                    data-driven solutions to scale poultry enterprises,
                    strengthen food supply chains, and promote sustainable
                    growth. His mission is to position poultry farming as a
                    modern, profitable, and impactful venture that creates jobs
                    and ensures food security.
                  </p>
                  <Badge
                    variant="secondary"
                    className="bg-primary/10 text-primary"
                  >
                    Visionary Leadership
                  </Badge>
                </div>
              </div>

              {/* COO Section */}
              <div className="flex items-start gap-6 mb-6 mt-8">
                <img
                  src={partner}
                  alt="COO - GreenField Agro"
                  className="w-36 h-36 rounded-full object-cover shadow-agro bg-muted"
                />
                <div>
                  <h4 className="text-xl font-bold text-primary mb-1">
                    Ibrahim Abbas Zubair
                  </h4>
                  <span className="block text-xs font-semibold text-primary/80 mb-2">
                    Chief Operating Officer (COO) & General Manager
                  </span>
                  <p className="text-muted-foreground mb-4 text-sm">
                    Bringing over 5 years of proven leadership in poultry
                    management and agribusiness operations. He holds a degree in
                    Computer Science and is a certified Business Administrator,
                    uniquely blending technical expertise with strong managerial
                    skills.
                  </p>
                  <p className="text-muted-foreground mb-4 text-sm">
                    With hands-on experience in farm operations, process
                    optimization, and team leadership, Ibrahim has successfully
                    improved efficiency, strengthened productivity, and ensured
                    sustainable growth in poultry production. His ability to
                    merge technology with modern farming practices positions him
                    as a forward-thinking leader dedicated to driving innovation
                    and excellence in agribusiness.
                  </p>
                  <Badge
                    variant="secondary"
                    className="bg-primary/10 text-primary"
                  >
                    Operational Excellence
                  </Badge>
                </div>
              </div>
            </div>

            {/* Company Registration */}
            <div className="bg-gradient-earth rounded-2xl p-6 text-center">
              <h4 className="text-lg font-bold text-primary mb-2">
                Officially Registered
              </h4>
              <p className="text-sm text-muted-foreground mb-2">
                GreenField Contracts & Agro Limited
              </p>
              <p className="text-sm font-mono text-primary">RC: 8834728</p>
            </div>
          </div>
        </div>

        {/* Our Values */}
        <div className="bg-muted/30 rounded-3xl p-8 lg:p-12">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-serif font-bold text-primary mb-4">
              Our Core Values
            </h3>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              These principles guide everything we do and shape our commitment
              to excellence.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const IconComponent = value.icon;
              return (
                <div key={index} className="text-center space-y-4 group">
                  <div className="mx-auto w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center group-hover:scale-110 transition-agro shadow-agro">
                    <IconComponent className="h-8 w-8 text-primary-foreground" />
                  </div>
                  <h4 className="text-xl font-semibold text-primary">
                    {value.title}
                  </h4>
                  <p className="text-muted-foreground leading-relaxed text-sm">
                    {value.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
