import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Award, Users, Leaf } from "lucide-react";
import hens from "@/assets/hens.jpeg";

const HeroSection = () => {
  return (
    <section
      id="home"
      className="relative min-h-screen bg-gradient-hero overflow-hidden"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-30">
        <div
          className="absolute inset-0 bg-white/5"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.05'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}
        ></div>
      </div>

      <div className="container mx-auto px-4 py-20 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-[80vh]">
          {/* Left Content */}
          <div className="text-primary-foreground space-y-8 animate-fade-in-up">
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-medium">
                <Award className="h-4 w-4" />
                Premium Agricultural Excellence
              </div>

              <h1 className="text-5xl lg:text-6xl font-serif font-bold leading-tight">
                Rooted in Growth,
                <span className="text-accent block">Driven by Excellence</span>
              </h1>

              <p className="text-xl text-primary-foreground/90 leading-relaxed max-w-lg">
                Leading Nigeria's agricultural revolution with premium poultry
                farming, fresh egg production, and sustainable farming
                solutions.
              </p>
            </div>

            {/* Stats */}
            <div className="flex gap-8 py-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-accent">5+</div>
                <div className="text-sm text-primary-foreground/80">
                  Years Experience
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-accent">100+</div>
                <div className="text-sm text-primary-foreground/80">
                  Satisfy Customers
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-accent">100%</div>
                <div className="text-sm text-primary-foreground/80">
                  Organic Quality
                </div>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/products" className="w-full sm:w-auto">
                <Button
                  size="lg"
                  className="w-full sm:w-auto bg-accent text-accent-foreground hover:bg-accent/90 shadow-agro-md hover:shadow-agro-lg transition-agro"
                >
                  Explore Products
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Button variant="hero" size="lg" className="w-full sm:w-auto">
                <Users className="mr-2 h-5 w-5" />
                Meet Our Team
              </Button>
            </div>
          </div>

          {/* Right Content - CEO & Product Showcase */}
          <div className="relative flex flex-col gap-8">
            {/* Video Showcase */}
            <div className="relative">
              <video
                className="w-full h-64 object-cover rounded-2xl shadow-agro-lg"
                controls
                autoPlay
                muted
                loop
                poster="/placeholder.svg"
              >
                <source src="/video.mp4" type="video/mp4" />
                Your browser does not support the video tag.
              </video>
            </div>

            {/* Product Showcase Image */}
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent rounded-2xl z-10"></div>
              <img
                src={hens}
                alt="Premium Chicken Production"
                className="w-full h-64 object-cover rounded-2xl shadow-agro-lg group-hover:scale-105 transition-agro"
              />
              <div className="absolute bottom-6 left-6 z-20 text-primary-foreground">
                <div className="flex items-center gap-2 mb-2">
                  <Leaf className="h-5 w-5 text-accent" />
                  <span className="text-sm font-medium">Premium Quality</span>
                </div>
                <h3 className="text-xl font-bold">Fresh Organic Chickens</h3>
                <p className="text-primary-foreground/80 text-sm">
                  Farm to table excellence. Our hens are raised in clean,
                  spacious environments and fed a balanced diet, ensuring
                  healthy chickens and superior eggs.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white/60 rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
