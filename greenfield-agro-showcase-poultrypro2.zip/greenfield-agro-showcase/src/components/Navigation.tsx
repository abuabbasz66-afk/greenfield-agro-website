import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Menu, X, Phone, Mail } from "lucide-react";
import greenfieldLogo from "@/assets/greenfield-logo.jpg";

const Navigation = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  return (
    <header className="bg-card/95 backdrop-blur-md border-b border-border sticky top-0 z-50 shadow-agro">
      <div className="container mx-auto px-4">
        {/* Top Contact Bar */}
        <div className="hidden md:flex justify-between items-center py-2 text-sm border-b border-border/50">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Phone className="h-4 w-4" />
              <span>08065301413 • 09046899965 • 08141584046</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Mail className="h-4 w-4" />
              <span>greenfieldcontractsagroltd@gmail.com</span>
            </div>
          </div>
          <div className="text-muted-foreground">Katsina State, Nigeria</div>
        </div>

        {/* Main Navigation */}
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <img
              src={greenfieldLogo}
              alt="GreenField Agro Logo"
              className="h-12 w-12 rounded-lg object-cover shadow-agro"
            />
            <div>
              <h1 className="font-serif text-xl font-bold text-primary">
                GREENFIELD
              </h1>
              <p className="text-xs text-muted-foreground font-medium">
                CONTRACTS & AGRO LIMITED
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8">
            <Link
              to="/"
              className="text-foreground hover:text-primary transition-agro font-medium"
            >
              Home
            </Link>
            <a
              href="/#about"
              className="text-foreground hover:text-primary transition-agro font-medium"
            >
              About
            </a>
            <Link
              to="/products"
              className="text-foreground hover:text-primary transition-agro font-medium"
            >
              Products
            </Link>
            <Link
              to="/poultrypro"
              className="text-primary hover:text-primary/80 transition-agro font-semibold"
            >
              PoultryPro
            </Link>
            <a
              href="/#services"
              className="text-foreground hover:text-primary transition-agro font-medium"
            >
              Services
            </a>
            <a
              href="/#contact"
              className="text-foreground hover:text-primary transition-agro font-medium"
            >
              Contact
            </a>
          </nav>

          {/* CTA Button */}
          <div className="hidden lg:block">
            <Button
              variant="default"
              className="bg-gradient-primary text-primary-foreground hover:shadow-agro-md transition-agro"
            >
              Get Quote
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={toggleMenu}
            className="lg:hidden p-2 text-foreground hover:text-primary transition-agro"
            aria-label="Toggle menu"
          >
            {isMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden pb-6 border-t border-border/50">
            <nav className="flex flex-col gap-4 pt-6">
              <Link
                to="/"
                className="text-foreground hover:text-primary transition-agro font-medium py-2"
                onClick={toggleMenu}
              >
                Home
              </Link>
              <a
                href="/#about"
                className="text-foreground hover:text-primary transition-agro font-medium py-2"
                onClick={toggleMenu}
              >
                About
              </a>
              <Link
                to="/products"
                className="text-foreground hover:text-primary transition-agro font-medium py-2"
                onClick={toggleMenu}
              >
                Products
              </Link>
              <Link
                to="/poultrypro"
                className="text-primary hover:text-primary/80 transition-agro font-semibold py-2"
                onClick={toggleMenu}
              >
                PoultryPro
              </Link>
              <a
                href="/#services"
                className="text-foreground hover:text-primary transition-agro font-medium py-2"
                onClick={toggleMenu}
              >
                Services
              </a>
              <a
                href="/#contact"
                className="text-foreground hover:text-primary transition-agro font-medium py-2"
                onClick={toggleMenu}
              >
                Contact
              </a>
              <Button
                variant="default"
                className="bg-gradient-primary text-primary-foreground mt-4 w-fit"
              >
                Get Quote
              </Button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Navigation;
