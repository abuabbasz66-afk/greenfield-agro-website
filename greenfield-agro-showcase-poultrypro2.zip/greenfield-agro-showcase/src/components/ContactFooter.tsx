import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Phone, Mail, MapPin, Clock, Send, Leaf } from "lucide-react";
import { Link } from "react-router-dom";
import greenfieldLogo from "@/assets/greenfield-logo.jpg";
import { useState } from "react";

const GOOGLE_SCRIPT_URL =
  "https://script.google.com/macros/s/AKfycbzNh7yPg-6zMisSk0vmvf-ImVEd7AK4NMy9ywjL2lbmPJCYVGAsV-VEqgONKFdqGoB2qA/exec";

const ContactFooter = () => {
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    subject: "",
    message: "",
    date: new Date().toISOString(), // Add date field to state
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");
  const [debug, setDebug] = useState("");

  // ✅ Add this: handle form inputs
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setForm((prev) => ({
      ...prev,
      [name]: value,
      date: new Date().toISOString(),
    })); // Update date on change
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setSuccess(false);

    const formBody = new URLSearchParams({
      name: form.name,
      phone: form.phone,
      email: form.email,
      subject: form.subject,
      message: form.message,
      date: form.date,
    });

    try {
      await fetch(GOOGLE_SCRIPT_URL, {
        method: "POST",
        mode: "no-cors",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: formBody.toString(),
      });

      setSuccess(true);
      setForm({
        name: "",
        phone: "",
        email: "",
        subject: "",
        message: "",
        date: new Date().toISOString(),
      });
    } catch {
      setError("Failed to send message. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // ✅ Contact Info
  const contactInfo = [
    {
      icon: Phone,
      title: "Phone Numbers",
      details: ["08065301413", "09046899965", "08141584046"],
      description: "Call us anytime for inquiries",
    },
    {
      icon: Mail,
      title: "Email Address",
      details: ["greenfieldcontractsagroltd@gmail.com"],
      description: "Send us your requirements",
    },
    {
      icon: MapPin,
      title: "Location",
      details: ["Along Mani Road, Katsina", "Katsina State, Nigeria"],
      description: "Visit our office",
    },
    {
      icon: Clock,
      title: "Business Hours",
      details: [
        "Monday - Friday: 8:00 AM - 6:00 PM",
        "Saturday: 8:00 AM - 4:00 PM",
        "Sunday: Closed",
      ],
      description: "We're here to serve you",
    },
  ];

  return (
    <section
      id="contact"
      className="py-20 bg-gradient-hero text-primary-foreground"
    >
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16 space-y-4">
          <Badge
            variant="outline"
            className="mb-4 border-primary-foreground/30 text-primary-foreground bg-white/10 backdrop-blur-sm"
          >
            Contact Us
          </Badge>
          <h2 className="text-4xl lg:text-5xl font-serif font-bold">
            Get in Touch
          </h2>
          <p className="text-xl text-primary-foreground/90 max-w-2xl mx-auto leading-relaxed">
            Ready to experience premium agricultural products? Contact us today
            for quotes, inquiries, or to learn more about our services.
          </p>
        </div>
        <div className="flex flex-col lg:grid lg:grid-cols-2 gap-12 mb-16">
          {/* Form */}
          <Card className="bg-white/10 backdrop-blur-sm border-white/20 shadow-agro-lg w-full">
            <CardHeader>
              <CardTitle className="text-2xl font-serif text-primary-foreground">
                Send us a Message
              </CardTitle>
              <CardDescription className="text-primary-foreground/80">
                Fill out the form below and we'll get back to you within 24
                hours.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-primary-foreground">
                      Full Name
                    </label>
                    <Input
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      placeholder="Enter your full name"
                      required
                      className="bg-white/10 border-white/20 text-primary-foreground placeholder:text-primary-foreground/60"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-primary-foreground">
                      Phone Number
                    </label>
                    <Input
                      name="phone"
                      value={form.phone}
                      onChange={handleChange}
                      placeholder="Enter your phone number"
                      required
                      className="bg-white/10 border-white/20 text-primary-foreground placeholder:text-primary-foreground/60"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-primary-foreground">
                    Email Address
                  </label>
                  <Input
                    name="email"
                    type="email"
                    value={form.email}
                    onChange={handleChange}
                    placeholder="Enter your email address"
                    required
                    className="bg-white/10 border-white/20 text-primary-foreground placeholder:text-primary-foreground/60"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-primary-foreground">
                    Subject
                  </label>
                  <Input
                    name="subject"
                    value={form.subject}
                    onChange={handleChange}
                    placeholder="What is this regarding?"
                    required
                    className="bg-white/10 border-white/20 text-primary-foreground placeholder:text-primary-foreground/60"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-primary-foreground">
                    Message
                  </label>
                  <Textarea
                    name="message"
                    value={form.message}
                    onChange={handleChange}
                    placeholder="Tell us about your requirements..."
                    rows={6}
                    required
                    className="bg-white/10 border-white/20 text-primary-foreground placeholder:text-primary-foreground/60"
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full bg-accent text-accent-foreground hover:bg-accent/90 shadow-agro-md hover:shadow-agro-lg transition-agro"
                  disabled={loading}
                >
                  <Send className="mr-2 h-5 w-5" />
                  {loading ? "Sending..." : "Send Message"}
                </Button>

                {success && (
                  <div className="text-green-500 text-center">
                    Message sent successfully!
                  </div>
                )}
                {error && (
                  <div className="text-red-500 text-center">{error}</div>
                )}
                {debug && (
                  <div className="text-xs text-yellow-500 text-center mt-2">
                    Debug: {debug}
                  </div>
                )}
              </form>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="space-y-6 w-full">
            {contactInfo.map((info, index) => {
              const IconComponent = info.icon;
              return (
                <Card
                  key={index}
                  className="bg-white/10 backdrop-blur-sm border-white/20 hover:bg-white/15 transition-agro"
                >
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="bg-accent rounded-full p-3 shadow-agro">
                        <IconComponent className="h-6 w-6 text-accent-foreground" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-primary-foreground mb-2">
                          {info.title}
                        </h3>
                        <div className="space-y-1 mb-2">
                          {info.details.map((detail, idx) => (
                            <p
                              key={idx}
                              className="text-primary-foreground/90 break-all"
                            >
                              {detail}
                            </p>
                          ))}
                        </div>
                        <p className="text-sm text-primary-foreground/70">
                          {info.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
        {/* Footer */}
        <div className="border-t border-white/20 pt-12">
          <div className="grid md:grid-cols-3 gap-8 items-center">
            {/* Logo & Company Info */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <img
                  src={greenfieldLogo}
                  alt="GreenField Agro Logo"
                  className="h-12 w-12 rounded-lg object-cover shadow-agro"
                />
                <div>
                  <h3 className="font-serif text-xl font-bold">GreenField</h3>
                  <p className="text-xs text-primary-foreground/80 font-medium">
                    CONTRACTS & AGRO LIMITED
                  </p>
                </div>
              </div>
              <div className="text-xs text-primary-foreground/70 space-y-1">
                <p>TIN: 1090176536</p> <p>CAC: RC8834728</p>
                <p>SCUML: SC212100827</p>
                <p>SMEDAN: SUID-0774-0889-4149-3533</p>
              </div>
              <p className="text-sm text-primary-foreground/80">
                • Rooted in Growth, Driven by Excellence
              </p>
            </div>
            {/* Quick Links */}
            <div className="text-center">
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <div className="space-y-2 text-sm">
                <Link
                  to="/"
                  className="block text-primary-foreground/80 hover:text-primary-foreground transition-agro"
                >
                  Home
                </Link>
                <a
                  href="/#about"
                  className="block text-primary-foreground/80 hover:text-primary-foreground transition-agro"
                >
                  About
                </a>
                <Link
                  to="/products"
                  className="block text-primary-foreground/80 hover:text-primary-foreground transition-agro"
                >
                  Products
                </Link>
                <a
                  href="/#contact"
                  className="block text-primary-foreground/80 hover:text-primary-foreground transition-agro"
                >
                  Contact
                </a>
              </div>
            </div>
            {/* Website */}
            <div className="text-center md:text-right">
              <div className="flex items-center justify-center md:justify-end gap-2 mb-2">
                <Leaf className="h-5 w-5 text-accent" />
                <span className="font-semibold">Visit Our Website</span>
              </div>
              <p className="text-accent font-medium">greenfieldagro.com.ng</p>
              <p className="text-xs text-primary-foreground/70 mt-2">
                © 2024 GreenField Contracts & Agro Limited. All rights reserved.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactFooter;
