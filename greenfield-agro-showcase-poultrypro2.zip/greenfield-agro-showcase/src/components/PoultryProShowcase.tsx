import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  ArrowRight,
  BarChart3,
  CloudSun,
  Egg,
  HeartPulse,
  ShieldCheck,
  Sparkles,
  Users,
  Wheat,
} from "lucide-react";

const features = [
  { icon: Egg, title: "Production Tracking", text: "Record eggs by room, compare performance, and turn daily figures into clear production insights." },
  { icon: Wheat, title: "Feed Management", text: "Track feed usage, consumption trends, costs, and operational efficiency across your flock." },
  { icon: HeartPulse, title: "Health & Mortality", text: "Keep structured health, mortality, vaccination, and flock records in one place." },
  { icon: BarChart3, title: "Farm Analytics", text: "Understand production, feed, flock, and financial performance through practical dashboards." },
  { icon: CloudSun, title: "Weather & Bird Advisory", text: "Connect farm conditions and weather information to poultry-specific risk and management guidance." },
  { icon: ShieldCheck, title: "Alerts & Intelligence", text: "Surface important farm events and turn records into timely management decisions." },
];

const PoultryProShowcase = () => (
  <section id="poultrypro" className="py-24 bg-gradient-to-br from-primary/[0.04] via-background to-accent/10">
    <div className="container mx-auto px-4">
      <div className="grid lg:grid-cols-2 gap-14 items-center">
        <div className="space-y-7">
          <Badge variant="outline" className="border-primary text-primary">
            GreenField Technology & Innovation
          </Badge>
          <div className="space-y-5">
            <h2 className="text-4xl lg:text-5xl font-serif font-bold text-primary leading-tight">
              Meet <span className="text-accent-foreground">PoultryPro</span>
            </h2>
            <p className="text-2xl font-semibold text-foreground">
              Capture. Understand. Predict.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed max-w-xl">
              PoultryPro is GreenField's digital poultry farm management solution, built to help farmers capture reliable farm records, understand performance, and make better day-to-day decisions.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            {features.slice(0, 4).map(({ icon: Icon, title, text }) => (
              <div key={title} className="rounded-xl border border-border/60 bg-card p-5 shadow-agro hover:shadow-agro-lg transition-agro">
                <Icon className="h-6 w-6 text-primary mb-3" />
                <h3 className="font-semibold text-primary mb-1">{title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{text}</p>
              </div>
            ))}
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <Link to="/poultrypro">
              <Button size="lg" className="bg-gradient-primary text-primary-foreground">
                Explore PoultryPro <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <a href="mailto:greenfieldcontractsagroltd@gmail.com?subject=PoultryPro%20Registration%20Interest">
              <Button size="lg" variant="outline">Register Interest</Button>
            </a>
          </div>
        </div>

        <div className="relative">
          <div className="absolute -inset-5 rounded-[2rem] bg-gradient-primary opacity-10 blur-2xl" />
          <div className="relative rounded-3xl border border-border/70 bg-card p-6 shadow-agro-strong">
            <div className="flex items-center justify-between border-b border-border pb-5 mb-6">
              <div>
                <p className="text-sm text-muted-foreground">PoultryPro Dashboard</p>
                <h3 className="text-2xl font-bold text-primary">Farm Intelligence</h3>
              </div>
              <div className="rounded-xl bg-primary/10 p-3">
                <Sparkles className="h-6 w-6 text-primary" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 mb-6">
              {[
                ["3,879", "Current Birds"],
                ["14,306", "Crates Recorded"],
                ["Feed", "Management"],
                ["AI", "Intelligence"],
              ].map(([value, label]) => (
                <div key={label} className="rounded-2xl bg-muted/60 p-5">
                  <div className="text-2xl font-bold text-primary">{value}</div>
                  <div className="text-sm text-muted-foreground mt-1">{label}</div>
                </div>
              ))}
            </div>
            <div className="rounded-2xl bg-gradient-hero p-6 text-primary-foreground">
              <div className="flex items-center gap-3 mb-3">
                <Users className="h-5 w-5" />
                <span className="font-semibold">Built for real farm teams</span>
              </div>
              <p className="text-sm text-primary-foreground/85 leading-relaxed">
                From farm managers and staff records to room-level production and advisory tools, PoultryPro brings the farm operation together.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

export default PoultryProShowcase;
