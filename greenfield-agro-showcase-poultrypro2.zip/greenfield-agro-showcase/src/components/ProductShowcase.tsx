import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Egg, Heart, Shield, Award, ArrowRight } from "lucide-react";
import { useSheetProducts } from "@/pages/Products";

const ProductShowcase = () => {
  const products = useSheetProducts();

  const qualityFeatures = [
    {
      icon: Shield,
      title: "Quality Assurance",
      description:
        "Every product undergoes strict quality control to ensure premium standards.",
    },
    {
      icon: Award,
      title: "Certified Organic",
      description:
        "Our farming practices are certified organic and environmentally sustainable.",
    },
    {
      icon: Heart,
      title: "Health Focused",
      description:
        "Nutrient-rich products that support healthy living and wellness.",
    },
  ];

  return (
    <section id="products" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16 space-y-4">
          <Badge variant="outline" className="mb-4 border-primary text-primary">
            Our Products
          </Badge>
          <h2 className="text-4xl lg:text-5xl font-serif font-bold text-primary">
            Premium Agricultural Products
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Discover our range of high-quality agricultural products, sourced
            and produced with the highest standards of excellence.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {products.length > 0 ? (
            products.map((product) => {
              // Use Egg icon for eggs, Heart for poultry, fallback to Egg
              const IconComponent =
                product.category === "eggs"
                  ? Egg
                  : product.category === "poultry"
                  ? Heart
                  : Egg;
              return (
                <Card
                  key={product.id}
                  className="group hover:shadow-agro-lg transition-agro border-border/50 overflow-hidden"
                >
                  <div className="relative overflow-hidden">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-64 object-cover group-hover:scale-105 transition-agro"
                    />
                    <div className="absolute top-4 right-4">
                      <Badge
                        variant={
                          product.availability === "In Stock"
                            ? "default"
                            : "secondary"
                        }
                        className="bg-card/90 backdrop-blur-sm"
                      >
                        {product.availability}
                      </Badge>
                    </div>
                    <div className="absolute top-4 left-4 bg-primary/90 backdrop-blur-sm rounded-full p-2">
                      <IconComponent className="h-5 w-5 text-primary-foreground" />
                    </div>
                  </div>

                  <CardHeader>
                    <CardTitle className="text-2xl font-serif text-primary">
                      {product.name}
                    </CardTitle>
                    <CardDescription className="text-base leading-relaxed">
                      {product.description}
                    </CardDescription>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-2xl font-bold text-primary">
                          ₦{product.price}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {product.unit}
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      {product.features &&
                        product.features.map((feature) => (
                          <Badge
                            key={feature}
                            variant="secondary"
                            className="text-xs bg-accent/20 text-accent-foreground"
                          >
                            {feature}
                          </Badge>
                        ))}
                    </div>
                  </CardContent>

                  <CardFooter>
                    <a
                      className="w-full bg-gradient-primary text-primary-foreground hover:shadow-agro-md transition-agro flex items-center justify-center px-4 py-2 rounded-md font-medium"
                      href={`https://wa.me/+2348065301413?text=Hello,%20I%20want%20to%20order%20${encodeURIComponent(
                        product.name
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Order Now
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </a>
                  </CardFooter>
                </Card>
              );
            })
          ) : (
            <div className="text-center text-muted-foreground py-12">
              Loading products...
            </div>
          )}
        </div>

        {/* Quality Features */}
        <div className="bg-card rounded-2xl p-8 shadow-agro">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-serif font-bold text-primary mb-4">
              Why Choose GreenField?
            </h3>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our commitment to excellence sets us apart in the agricultural
              industry.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {qualityFeatures.map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <div key={index} className="text-center space-y-4 group">
                  <div className="mx-auto w-16 h-16 bg-gradient-primary rounded-full flex items-center justify-center group-hover:scale-110 transition-agro shadow-agro">
                    <IconComponent className="h-8 w-8 text-primary-foreground" />
                  </div>
                  <h4 className="text-xl font-semibold text-primary">
                    {feature.title}
                  </h4>
                  <p className="text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProductShowcase;
