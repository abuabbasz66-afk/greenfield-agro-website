import { Link } from "react-router-dom";
import { ArrowLeft, ArrowRight, BarChart3, Bird, CloudSun, Egg, HeartPulse, ShieldCheck, Sparkles, Users, Wheat } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Navigation from "@/components/Navigation";

const capabilities = [
  { icon: Egg, title: "Daily Production", text: "Record production by room, calculate totals, convert eggs to crates, and compare room performance." },
  { icon: Wheat, title: "Feed Management", text: "Monitor feed issued and consumed, costs, usage patterns, and efficiency across the farm." },
  { icon: Bird, title: "Flock Management", text: "Manage flock information and dedicated workflows for layers, broilers, noilers, brooding, and rearing." },
  { icon: HeartPulse, title: "Health & Mortality", text: "Maintain health records, vaccination information, mortality logs, and important flock events." },
  { icon: BarChart3, title: "Analytics & Finance", text: "Turn farm records into useful production, cost, financial, and performance insights." },
  { icon: CloudSun, title: "Weather & Bird Advisory", text: "Use weather and flock context to provide practical poultry-specific risk and management guidance." },
  { icon: Users, title: "Staff & Users", text: "Support farm teams with staff records, user access, and structured operational responsibilities." },
  { icon: ShieldCheck, title: "Alerts & Intelligence", text: "Highlight important changes and provide intelligent prompts to help managers act earlier." },
];

const PoultryPro = () => (
  <div className="min-h-screen bg-background">
    <Navigation />

    <section className="relative overflow-hidden bg-gradient-hero text-primary-foreground py-24 lg:py-32">
      <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_top_right,white,transparent_35%)]" />
      <div className="container mx-auto px-4 relative z-10">
        <Link to="/" className="inline-flex items-center text-primary-foreground/80 hover:text-primary-foreground mb-10 transition-agro">
          <ArrowLeft className="h-4 w-4 mr-2" /> Back to GreenField
        </Link>
        <div className="max-w-4xl">
          <Badge className="mb-6 bg-white/10 text-white border-white/20 hover:bg-white/10">
            GreenField Technology & Innovation
          </Badge>
          <h1 className="text-5xl lg:text-7xl font-serif font-bold leading-tight mb-6">
            PoultryPro
          </h1>
          <p className="text-2xl lg:text-3xl font-semibold text-accent mb-7">
            Capture. Understand. Predict.
          </p>
          <p className="text-xl text-primary-foreground/90 max-w-3xl leading-relaxed mb-10">
            A digital poultry farm management solution designed to help farmers capture reliable records, understand farm performance, and make smarter operational decisions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <a href="mailto:greenfieldcontractsagroltd@gmail.com?subject=PoultryPro%20Registration%20Interest">
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
                Register Interest <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </a>
            <a href="#features">
              <Button size="lg" variant="outline" className="border-white/30 bg-white/5 text-white hover:bg-white/10 hover:text-white">
                Explore Features
              </Button>
            </a>
          </div>
        </div>
      </div>
    </section>

    <section id="features" className="py-24">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mb-14">
          <Badge variant="outline" className="border-primary text-primary mb-4">What PoultryPro Does</Badge>
          <h2 className="text-4xl lg:text-5xl font-serif font-bold text-primary mb-5">One platform for the farm operation</h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            PoultryPro brings core farm records, dashboards, advisory tools, and management workflows into one connected digital experience.
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
          {capabilities.map(({ icon: Icon, title, text }) => (
            <div key={title} className="group rounded-2xl border border-border bg-card p-6 shadow-agro hover:shadow-agro-lg hover:-translate-y-1 transition-agro">
              <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary group-hover:text-primary-foreground transition-agro">
                <Icon className="h-6 w-6 text-primary group-hover:text-primary-foreground" />
              </div>
              <h3 className="text-xl font-semibold text-primary mb-3">{title}</h3>
              <p className="text-muted-foreground leading-relaxed">{text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className="py-24 bg-muted/40">
      <div className="container mx-auto px-4">
        <div className="rounded-3xl bg-card border border-border shadow-agro-lg overflow-hidden">
          <div className="grid lg:grid-cols-2">
            <div className="p-8 lg:p-12">
              <Badge variant="outline" className="border-primary text-primary mb-5">Designed around farm records</Badge>
              <h2 className="text-3xl lg:text-4xl font-serif font-bold text-primary mb-5">From records to decisions</h2>
              <p className="text-lg text-muted-foreground leading-relaxed mb-7">
                The platform is designed around the information farmers already need to manage: flock numbers, room production, feed, mortality, health, prices, staff, and operating costs.
              </p>
              <div className="space-y-4">
                {[
                  "Room-level production and farm aggregation",
                  "Broken eggs, feed, mortality, health, and price records",
                  "Room comparison and farm performance dashboards",
                  "Weather-aware poultry guidance",
                  "Dedicated layer, broiler, noiler, brooding, and rearing workflows",
                ].map((item) => (
                  <div key={item} className="flex items-start gap-3">
                    <ShieldCheck className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                    <span className="text-foreground">{item}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-gradient-hero p-8 lg:p-12 text-primary-foreground flex items-center">
              <div>
                <Sparkles className="h-10 w-10 text-accent mb-6" />
                <h3 className="text-3xl font-serif font-bold mb-5">Built for smarter poultry management</h3>
                <p className="text-primary-foreground/85 text-lg leading-relaxed mb-8">
                  PoultryPro is being developed as a practical digital tool for farmers, farm managers, staff, and poultry businesses that want better visibility over their operations.
                </p>
                <a href="mailto:greenfieldcontractsagroltd@gmail.com?subject=PoultryPro%20Registration%20Interest">
                  <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
                    Talk to GreenField <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <footer className="py-10 border-t border-border">
      <div className="container mx-auto px-4 flex flex-col sm:flex-row justify-between gap-4 text-sm text-muted-foreground">
        <span>© {new Date().getFullYear()} GreenField Contracts & Agro Limited</span>
        <Link to="/" className="hover:text-primary transition-agro">GreenField Agro</Link>
      </div>
    </footer>
  </div>
);

export default PoultryPro;
