import Navigation from "@/components/Navigation";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import ProductShowcase from "@/components/ProductShowcase";
import PoultryProShowcase from "@/components/PoultryProShowcase";
import ContactFooter from "@/components/ContactFooter";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main>
        <HeroSection />
        <AboutSection />
        <ProductShowcase />
        <PoultryProShowcase />
        <ContactFooter />
      </main>
    </div>
  );
};

export default Index;
