import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import {
  ArrowLeft,
  Search,
  Filter,
  Star,
  Heart,
  Egg,
  Bird,
  Wheat,
  Milk,
  Leaf,
} from "lucide-react";
import { Link } from "react-router-dom";
import Navigation from "@/components/Navigation";
import eggShowcase from "@/assets/eggs-showcase.jpeg";
import layersImg from "@/assets/layers.jpeg";
import broilersMedium from "@/assets/BroilersMedium.jpeg";
import broilersLarge1 from "@/assets/BroilersLarge1.jpeg";
import broilersLarge2 from "@/assets/BroilersLarge2.jpeg";
import poultryDung1 from "@/assets/poultryDung1.jpeg";

export const useSheetProducts = () => {
  const [sheetProducts, setSheetProducts] = useState([]);
  useEffect(() => {
    const fetchProductsFromSheet = async () => {
      // Use the published Google Sheets CSV export URL (CORS-safe)
      const url =
        "https://docs.google.com/spreadsheets/d/e/2PACX-1vSWfXyKmdQ193-oNUJmgBSnPTvpgdvQIt2cKa2xEkIbt6era3rvdgCCbepHTZ45NVHIwkWIxfiZoDMd/pub?output=csv";
      const res = await fetch(url);
      const text = await res.text();
      const lines = text.split("\n").filter(Boolean);
      const headers = lines[0].split(",");
      setSheetProducts(
        lines.slice(1).map((line, idx) => {
          const cols = line.split(",");
          let image = cols[headers.indexOf("image")] || "";
          const category = (
            cols[headers.indexOf("category")] || ""
          ).toLowerCase();
          const name = (cols[headers.indexOf("name")] || "").toLowerCase();
          const desc = (
            cols[headers.indexOf("description")] || ""
          ).toLowerCase();
          // Alternate images for broilers and poultry dung
          if (!image) {
            if (category.includes("egg") || name.includes("egg"))
              image = eggShowcase;
            else if (
              category.includes("layer") ||
              name.includes("layer") ||
              name.includes("spent")
            )
              image = layersImg;
            // Inside useSheetProducts, replace this part:
            else if (name.includes("broiler")) {
              // ✅ For live poultry broilers — use only one image per type
              if (desc.includes("large"))
                image = broilersLarge1; // use only first large image
              else if (desc.includes("medium"))
                image = broilersMedium; // use only first medium image
              else image = broilersLarge1; // fallback if not specified
            }
            // ✅ fixed block ends properly here
            else if (
              (category.includes("poultry") &&
                (desc.includes("dung") ||
                  name.includes("dung") ||
                  name.includes("manure"))) ||
              name.includes("dung") ||
              name.includes("manure")
            )
              image = poultryDung1;
            // ✅ use only the first image (no alternating)
            else if (category.includes("poultry")) image = layersImg;
            else image = eggShowcase;
          }
          return {
            id: cols[headers.indexOf("id")] || "",
            name: cols[headers.indexOf("name")] || "",
            category,
            description: cols[headers.indexOf("description")] || "",
            image,
            price: cols[headers.indexOf("price")] || "",
            originalPrice: cols[headers.indexOf("originalPrice")] || "",
            unit: cols[headers.indexOf("unit")] || "",
            rating: parseFloat(cols[headers.indexOf("rating")] || "0"),
            reviews: parseInt(cols[headers.indexOf("reviews")] || "0"),
            features: cols[headers.indexOf("features")]
              ? cols[headers.indexOf("features")].split(";")
              : [],
            availability: cols[headers.indexOf("availability")] || "",
            discount: cols[headers.indexOf("discount")] || "",
          };
        })
      );
    };
    fetchProductsFromSheet();
  }, []);
  return sheetProducts;
};

const Products = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const sheetProducts = useSheetProducts();

  const productCategories = [
    { id: "all", name: "All Products", icon: Wheat },
    { id: "eggs", name: "Fresh Eggs", icon: Egg },
    { id: "dung", name: "Poultry Dung", icon: Heart }, // Move dung under eggs
    { id: "poultry", name: "Live Poultry", icon: Bird },
    // { id: "dairy", name: "Dairy Products", icon: Milk },
  ];

  const filteredProducts = sheetProducts.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description.toLowerCase().includes(searchTerm.toLowerCase());
    let matchesCategory = false;
    if (selectedCategory === "all") {
      matchesCategory = true;
    } else if (selectedCategory === "dung") {
      // Show products with dung/manure in name, description, or category
      const n = product.name.toLowerCase();
      const d = product.description.toLowerCase();
      const c = product.category.toLowerCase();
      matchesCategory =
        n.includes("dung") ||
        n.includes("manure") ||
        d.includes("dung") ||
        d.includes("manure") ||
        c.includes("dung") ||
        c.includes("manure");
    } else if (selectedCategory === "poultry") {
      // Show products with broiler, layer, or spent in name/desc/category
      const n = product.name.toLowerCase();
      const d = product.description.toLowerCase();
      const c = product.category.toLowerCase();
      matchesCategory =
        n.includes("broiler") ||
        n.includes("layer") ||
        n.includes("spent") ||
        d.includes("broiler") ||
        d.includes("layer") ||
        d.includes("spent") ||
        c.includes("broiler") ||
        c.includes("layer") ||
        c.includes("spent");
    } else {
      matchesCategory = product.category === selectedCategory;
    }
    return matchesSearch && matchesCategory;
  });

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < Math.floor(rating)
            ? "fill-yellow-400 text-yellow-400"
            : "text-gray-300"
        }`}
      />
    ));
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      {/* Header */}
      <section className="bg-gradient-hero text-primary-foreground py-16">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-4 mb-6">
            <Link to="/">
              <Button
                variant="outline"
                size="sm"
                className="border-primary/30 text-primary hover:bg-primary/10 hover:text-primary-foreground transition-agro"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
            </Link>
          </div>

          <div className="max-w-2xl">
            <h1 className="text-4xl lg:text-5xl font-serif font-bold mb-4">
              Our Premium Products
            </h1>
            <p className="text-xl text-primary-foreground/90 leading-relaxed">
              Discover our complete range of high-quality agricultural products,
              from fresh eggs to healthy poultry and dairy products.
            </p>
          </div>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="py-8 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <div className="flex items-center gap-2">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Category:</span>
            </div>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="py-12">
        <div className="container mx-auto px-4">
          <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
            <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:grid-cols-4 mb-8">
              {productCategories.map((category) => {
                const IconComponent = category.icon;
                return (
                  <TabsTrigger
                    key={category.id}
                    value={category.id}
                    className="flex items-center gap-2"
                  >
                    <IconComponent className="h-4 w-4" />
                    <span className="hidden sm:inline">{category.name}</span>
                  </TabsTrigger>
                );
              })}
            </TabsList>

            {productCategories.map((category) => (
              <TabsContent key={category.id} value={category.id}>
                <div className="mb-6">
                  <h2 className="text-2xl font-serif font-bold text-primary mb-2">
                    {category.name}
                  </h2>
                  <p className="text-muted-foreground">
                    {filteredProducts.length} products available
                  </p>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {filteredProducts.map((product) => (
                    <Card
                      key={product.id}
                      className="group hover:shadow-agro-lg transition-agro border-border/50 overflow-hidden"
                    >
                      <div className="relative overflow-hidden">
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-full h-48 object-cover group-hover:scale-105 transition-agro"
                        />
                        <div className="absolute top-3 left-3 flex flex-col gap-2">
                          <Badge
                            variant={
                              product.availability === "In Stock"
                                ? "default"
                                : product.availability === "Limited Stock"
                                ? "secondary"
                                : "outline"
                            }
                            className="text-xs"
                          >
                            {product.availability}
                          </Badge>
                          {product.discount && (
                            <Badge variant="destructive" className="text-xs">
                              {product.discount}
                            </Badge>
                          )}
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-agro bg-white/90 backdrop-blur-sm"
                        >
                          <Heart className="h-4 w-4" />
                        </Button>
                      </div>

                      <CardHeader className="pb-2">
                        <div className="flex items-start justify-between">
                          <CardTitle className="text-lg font-semibold text-primary line-clamp-1">
                            {product.name}
                          </CardTitle>
                        </div>
                        <CardDescription className="text-sm leading-relaxed line-clamp-2">
                          {product.description}
                        </CardDescription>
                      </CardHeader>

                      <CardContent className="space-y-3">
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-1">
                            {renderStars(product.rating)}
                          </div>
                          <span className="text-sm text-muted-foreground">
                            {product.rating} ({product.reviews} reviews)
                          </span>
                        </div>

                        <div className="flex items-center justify-between">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xl font-bold text-primary">
                                {product.price}
                              </span>
                              {product.originalPrice && (
                                <span className="text-sm text-muted-foreground line-through">
                                  {product.originalPrice}
                                </span>
                              )}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {product.unit}
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-1">
                          {product.features.slice(0, 3).map((feature) => (
                            <Badge
                              key={feature}
                              variant="secondary"
                              className="text-xs bg-accent/20 text-accent-foreground"
                            >
                              {feature}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>

                      <CardFooter className="pt-0">
                        <a
                          className="w-full bg-gradient-primary text-primary-foreground hover:shadow-agro-md transition-agro flex items-center justify-center px-4 py-2 rounded-md font-medium"
                          href={`https://wa.me/+2348065301413?text=Hello,%20I%20want%20to%20order%20${encodeURIComponent(
                            product.name
                          )}`}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          Order Now
                          <Heart className="ml-2 h-4 w-4" />
                        </a>
                      </CardFooter>
                    </Card>
                  ))}
                </div>

                {filteredProducts.length === 0 && (
                  <div className="text-center py-12">
                    <div className="text-muted-foreground mb-4">
                      <Wheat className="h-12 w-12 mx-auto mb-4 opacity-50" />
                      No products found matching your criteria.
                    </div>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setSearchTerm("");
                        setSelectedCategory("all");
                      }}
                    >
                      Clear Filters
                    </Button>
                  </div>
                )}
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-hero text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-serif font-bold mb-4">
            Need Custom Orders?
          </h2>
          <p className="text-xl text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
            We can accommodate bulk orders and custom requirements. Contact us
            for special pricing and delivery options.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-accent text-accent-foreground hover:bg-accent/90"
            >
              Request Custom Quote
            </Button>
            <Link to="/#contact">
              <Button
                variant="outline"
                size="lg"
                className="border-primary/30 text-primary hover:bg-primary/10 hover:text-primary-foreground transition-agro"
              >
                Contact Sales Team
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Products;
